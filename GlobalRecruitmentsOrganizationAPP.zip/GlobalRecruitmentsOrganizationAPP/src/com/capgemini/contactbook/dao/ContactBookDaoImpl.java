package com.capgemini.contactbook.dao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.capgemini.contactbook.bean.EnquiryBean;
import com.capgemini.contactbook.exception.ContactBookException;
import com.capgemini.contactbook.util.DBConnection;




public class ContactBookDaoImpl implements ContactBookDao {
	
	Logger logger=Logger.getRootLogger();
	
	public ContactBookDaoImpl()
	{
	PropertyConfigurator.configure("resources//log4j.properties");
	
	}
	
	@SuppressWarnings("resource")
	public String addEnquiry(EnquiryBean enquirybean) throws ContactBookException 
	{
		Connection connection = DBConnection.getInstance().getConnection();	
		//creating prepared statement
		PreparedStatement preparedStatement=null;		
		ResultSet resultSet = null;
		
		String enquiryId=null;
		
		int queryResult=0;
		try
		{	
			
			preparedStatement=connection.prepareStatement(QueryMapper.INSERT_QUERY);

			
			preparedStatement.setString(1, enquirybean.getfName());
			preparedStatement.setString(2, enquirybean.getlName());
			preparedStatement.setString(3, enquirybean.getContactNo());
			preparedStatement.setString(4, enquirybean.getpLocation());
				
			preparedStatement.setString(5, enquirybean.getpDomain());
			queryResult=preparedStatement.executeUpdate();
		
			preparedStatement = connection.prepareStatement(QueryMapper.ENQUIRYID_QUERY_SEQUENCE);
			resultSet=preparedStatement.executeQuery();

			if(resultSet.next())
			{
				enquiryId=resultSet.getString(1);
						
			}
	
			if(queryResult==0)
			{
				logger.error("Insertion failed ");
				throw new ContactBookException("Inserting enuiry details failed ");

			}
			else
			{
				logger.info("enquiry details added successfully:");
				return enquiryId;
			}

		}
		catch(SQLException sqlException)
		{
			sqlException.printStackTrace();
			logger.error(sqlException.getMessage());
			throw new ContactBookException("Tehnical problem occured refer log");
		}

		finally
		{
			try 
			{
				//resultSet.close();
				preparedStatement.close();
				connection.close();
			}
			catch (SQLException sqlException) 
			{
				sqlException.printStackTrace();
				logger.error(sqlException.getMessage());
				throw new ContactBookException("Error in closing db connection");

			}
		}
		

		
	}

	@Override
	public EnquiryBean viewEnquiryDetails(String enquiryId) throws ContactBookException {
		// TODO Auto-generated method stub
		
Connection connection=DBConnection.getInstance().getConnection();
		
		
		PreparedStatement preparedStatement=null;
		ResultSet resultset = null;
		EnquiryBean bean=null;
		
		try
		{
			preparedStatement=connection.prepareStatement(QueryMapper.VIEW_ContactBook_DETAILS_QUERY);
			preparedStatement.setString(1,enquiryId);
			resultset=preparedStatement.executeQuery();
			
			if(resultset.next())
			{
				bean = new EnquiryBean();
				bean.setfName(resultset.getString(1));
				bean.setlName(resultset.getString(2));
				bean.setContactNo(resultset.getString(3));
				bean.setpDomain(resultset.getString(4));
				bean.setpLocation(resultset.getString(5));
								
			}
			
			if( bean != null)
			{
				logger.info("Details Found Successfully");
				return bean;
			}
			else
			{
				logger.info("Details Not Found Successfully");
				return null;
			}
			
		}
		catch(Exception e)
		{
			logger.error(e.getMessage());
			throw new ContactBookException(e.getMessage());
		}
		finally
		{
			try 
			{
				resultset.close();
				preparedStatement.close();
				connection.close();
			} 
			catch (SQLException e) 
			{
				logger.error(e.getMessage());
				throw new ContactBookException("Error in closing db connection");

			}
		}
		
	}

		


	@Override
	public List<EnquiryBean> retriveAll() throws ContactBookException {
		// TODO Aut-generated method stub
		
		
		Connection con=DBConnection.getInstance().getConnection();
		int contactbookCount = 0;
		
		PreparedStatement ps=null;
		ResultSet resultset = null;
		
		List<EnquiryBean> bookList=new ArrayList<EnquiryBean>();
		try
		{
			ps=con.prepareStatement(QueryMapper.RETRIVE_ALL_QUERY);
			resultset=ps.executeQuery();
			
			while(resultset.next())
			{	
				EnquiryBean bean=new EnquiryBean();
				
				bean.setfName(resultset.getString(1));
				bean.setlName(resultset.getString(2));
				bean.setContactNo(resultset.getString(3));
				bean.setpDomain(resultset.getString(4));
				bean.setpLocation(resultset.getString(5));
								
				bookList.add(bean);
				
				contactbookCount++;
			}			
			
		} catch (SQLException sqlException) {
			logger.error(sqlException.getMessage());
			throw new ContactBookException("Tehnical problem occured. Refer log");
		}
		
		finally
		{
			try 
			{
				//resultset.close();
				ps.close();
				con.close();
			} 
			catch (SQLException e) 
			{
				logger.error(e.getMessage());
				throw new ContactBookException("Error in closing db connection");

			}
		}
		
		if( contactbookCount == 0)
			return null;
		else
			return bookList;
	}	
	}

	
	
	
	

	
