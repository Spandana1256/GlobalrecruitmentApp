package com.capgemini.contactbook.dao;

import java.util.List;

import com.capgemini.contactbook.bean.EnquiryBean;
import com.capgemini.contactbook.exception.ContactBookException;


//creating interface
public interface ContactBookDao {
	public String addEnquiry(EnquiryBean enquirybean) throws ContactBookException;

	public List<EnquiryBean> retriveAll()throws ContactBookException;
	public EnquiryBean viewEnquiryDetails(String enquiryId) throws ContactBookException;
}


